namespace aufgabe13 {
    export class AlleObjekte {
        ofType: string;
        x: number;
        y: number;

        constructor() {
            //
        }

        draw(): void {
            //
        }

        update(): void {
            this.draw();
            this.fressFische();
        }

        fressFische(){
            //
        }

    }
}