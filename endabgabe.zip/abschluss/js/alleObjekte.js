var aufgabe13;
(function (aufgabe13) {
    class AlleObjekte {
        constructor() {
            //
        }
        draw() {
            //
        }
        update() {
            this.draw();
            this.fressFische();
        }
        fressFische() {
            //
        }
    }
    aufgabe13.AlleObjekte = AlleObjekte;
})(aufgabe13 || (aufgabe13 = {}));
//# sourceMappingURL=alleObjekte.js.map